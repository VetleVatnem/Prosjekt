import matplotlib.pyplot as plt
import numpy as np

def aliasing():